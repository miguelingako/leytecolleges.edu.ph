// Function to fetch student data from the JSON file
async function fetchStudentData() {
    try {
        const response = await fetch('https://sapphire-lauralee-50.tiiny.site/students.json'); // Adjust the path as needed
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        const data = await response.json();
        return data;
    } catch (error) {
        console.error('There has been a problem with your fetch operation:', error);
    }
}

// Function to load and display student data
async function loadStudentData() {
    const studentId = localStorage.getItem('studentId');
    const students = await fetchStudentData(); // Fetch student data from the JSON file

    if (students && students[studentId]) {
        const student = students[studentId];
        document.getElementById('student-name').textContent = student.name;

        // Populate Grades
        const gradesTable = document.getElementById('grades-table');
        gradesTable.innerHTML = student.grades.map(g => `
            <tr>
                <td>${g.subject}</td>                            
                <td>${g.grade}</td>
                <td>${g.units}</td>
            </tr>
        `).join('');

        // Populate Schedule
        const scheduleTable = document.getElementById('schedule-table');
        scheduleTable.innerHTML = student.schedule.map(s => `
            <tr>
                <td>${s.day}</td>
                <td>${s.time}</td>
                <td>${s.subject}</td>
            </tr>
        `).join('');

        // Populate Billing
        const backaccountTable = document.getElementById('backaccount-table');
        backaccountTable.innerHTML = student.backaccount.map(b => `
            <tr>
                <td>${b.bill}</td>
                <td>${b.enrollment}</td>
                <td style="background-color:yellow"><b style="Color:red">${b.due}</b></td>
            </tr>
        `).join('');

        // Populate Exam Bill
        const exambillTable = document.getElementById('exambill-table');
        exambillTable.innerHTML = student.exambill.map(x => `
            <tr>                
                <td>${x.midterm}</td>
                <td>${x.semifinals}</td>
                <td>${x.finals}</td>                
            </tr>
        `).join('');
    } else {
        document.querySelector('.main-content').innerHTML = '<p style="text-align:center"><b>Please Log in to see your data. <a href="index.html">Click to Login</a></b></p>';
    }
}

function toggleMenu() {
    const sidebar = document.querySelector('.sidebar');
    const mainContent = document.querySelector('.main-content');
    if (sidebar.style.width === '250px') {
        sidebar.style.width = '0';
        mainContent.style.marginLeft = '0';
    } else {
        sidebar.style.width = '250px';
        mainContent.style.marginLeft = '250px';
    }
}

function logout() {
    localStorage.removeItem('studentId');
    if ('caches' in window) {
        caches.keys().then(function(names) {
            for (let name of names) {
                caches.delete(name);
            }
        });
    }

    // Redirect to the index page
    window.location.href = 'index.html';
}

// Load student data when the page is ready
document.addEventListener('DOMContentLoaded', loadStudentData);