const students = {
    '2019-14411-1': { name: 'Miguel Morden', password: 'password1' },
    '2019-15511-6': { name: 'Aljun Cabrera', password: 'password2' },
    '2021-0462': { name: 'Renelyn Gregorio', password: 'password3' },
    '2019-16611-1': { name: 'Antony Taberba', password: 'password4' },
    '2024-56778-1': { name: 'Student 5', password: 'password5' },
};

function login() {
    const studentId = document.getElementById('student-id').value.trim();
    const password = document.getElementById('password').value;
    const errorElement = document.getElementById('login-error');

    if (students[studentId] && students[studentId].password === password) {
        localStorage.setItem('studentId', studentId);
        window.location.href = 'dashboard.html';
    } else {
        errorElement.textContent = 'Incorrect Student ID or Password';
    }
}

