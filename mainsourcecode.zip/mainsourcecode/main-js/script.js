// Slide menu functions
function openMenu() {
    document.getElementById("sideMenu").style.width = "250px";
}

function closeMenu() {
    document.getElementById("sideMenu").style.width = "0";
}

document.addEventListener('click', function(event) {
    const sideMenu = document.getElementById('sideMenu');
    const menuButton = document.querySelector('.menu-btn');
    if (!sideMenu.contains(event.target) && !menuButton.contains(event.target)) {
        closeMenu();
    }
});
