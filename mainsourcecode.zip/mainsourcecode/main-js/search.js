// Define an array of content items with their titles and URLs
const contentItems = [
    { title: "Home", url: "home.html" },
    { title: "About Us", url: "aboutus.html" },
    { title: "Log in", url: "index.html" },
    { title: "Student Portal", url: "index.html" },
    { title: "Admission", url: "admission.html" },
    { title: "Academics", url: "academics.html" },
    { title: "Enrollment Form", url: "olform.html" },
     { title: "Download Enrollment Form", url: "formdl.html" }
    
];

// Function to search and display content
function searchContent() {
    let filter = document.getElementById('searchBar').value.toLowerCase();
    let contentContainer = document.getElementById('content');

    // If the search bar is empty, hide the content container and return early
    if (filter.trim() === '') {
        contentContainer.style.display = 'none';
        return;
    }

    // Clear previous search results
    contentContainer.innerHTML = '';

    // Filter content items based on search term
    let filteredItems = contentItems.filter(item => item.title.toLowerCase().includes(filter));

    if (filteredItems.length > 0) {
        contentContainer.style.display = 'block'; // Show the content container

        // Dynamically create and append matching items
        filteredItems.forEach(item => {
            let div = document.createElement('div');
            div.className = 'item';
            div.textContent = item.title;
            div.setAttribute('data-url', item.url);

            // Add click event to navigate to the corresponding page
            div.addEventListener('click', function () {
                window.location.href = item.url;
            });

            contentContainer.appendChild(div);
        });
    } else {
        contentContainer.style.display = 'none'; // Hide the content container if no match is found
    }
}

// Trigger search on button click
document.getElementById('searchButton').addEventListener('click', searchContent);