const menuBtn = document.getElementById("menuToggle");
const menuContainer = document.querySelector(".hamburger-menu-container");

menuBtn.addEventListener("click", function () {
  // Toggle menu content visibility
  menuContainer.classList.toggle("menu-open");
  
  // Change hamburger button appearance
  menuBtn.classList.toggle("change");
});

const collapsible = document.querySelector('.collapsible');
const content = document.querySelector('.content');

collapsible.addEventListener('click', function () {
    if (content.style.maxHeight) {
        content.style.maxHeight = null;
        content.style.padding = "0 18px";
    } else {
        content.style.maxHeight = content.scrollHeight + "px";
        content.style.padding = "18px";
    }
});

const button = document.querySelector('.button');
const modal = document.querySelector('.modal');
const closeButton = document.querySelector('.close-button');

button.addEventListener('click', function () {
    modal.classList.add('show'); // Show the modal
    const modalContent = modal.querySelector('.modal-content');
    modalContent.classList.add('show'); // Show content with transition
});

closeButton.addEventListener('click', function () {
    modal.classList.remove('show'); // Hide the modal
    const modalContent = modal.querySelector('.modal-content');
    modalContent.classList.remove('show'); // Hide content with transition
});

// Close modal when clicking outside the content
modal.addEventListener('click', function (event) {
    if (event.target === modal) {
        modal.classList.remove('show');
        const modalContent = modal.querySelector('.modal-content');
        modalContent.classList.remove('show');
    }
});